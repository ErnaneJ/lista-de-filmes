## Prática - Lista de Filmes

Aplicativo para armazenar uma lista de filmes que 
um usuário assistiu feito com  Tkinter.